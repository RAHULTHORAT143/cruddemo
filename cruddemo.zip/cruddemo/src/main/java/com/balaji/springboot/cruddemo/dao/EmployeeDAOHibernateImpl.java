package com.balaji.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.balaji.springboot.cruddemo.entity.Employee;

@Repository
public class EmployeeDAOHibernateImpl implements EmployeeDAO {
	
	
	//define fields for entitymanager
	@Autowired
	private EntityManager entityManager;
	
	//setup the constructor injection
	public EmployeeDAOHibernateImpl(EntityManager theEntityManager) {
		
		entityManager=theEntityManager;
	}
		
	@Override
	public List<Employee> findAll() {
		//get the current hibernate seession 
		Session currentSession =entityManager.unwrap(Session.class);
		
		//create the query 
		Query<Employee> theQuery =currentSession.createQuery("from Employee",Employee.class);
		
		//execute the query and get the reslt list 
		
	List<Employee>  employees=theQuery.getResultList();
		
		//return results
		
		return employees;
	}

	@Override
	public Employee findById(int theId) {

		//get the current hibernate session 
		Session currentSession =entityManager.unwrap(Session.class);
		
		//get the  employee 
		Employee theEmployee =currentSession.get(Employee.class,theId);
		
		//return the employee
		
		return theEmployee;
	}

	@Override
	public void save(Employee theEmployee) {

		Session currentSession =entityManager.unwrap(Session.class);
		
		currentSession.saveOrUpdate(theEmployee);
		
	}

	@Override
	public void deleteById(int theId) {
		
		Session currentSession =entityManager.unwrap(Session.class);
		
		//delete the objecct with Primary Key
		
		Query theQuery=currentSession.createQuery("delete from Employee where id=:employeeId");
		
		theQuery.setParameter("employeeId", theId)	;
		
		theQuery.executeUpdate();
		
	}
	
	
	

}
